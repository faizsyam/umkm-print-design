# Phase 3: Design Plan, part 1 of 2: plan criteria, territory survey, core idea, style, hero

One unified, defensible, original direction: plan criteria, brand design and theme, a territory survey, and the core idea, style, and hero chosen in that order by the full protocol.

**Inputs needed:** S; Phase 2 Forward (Communication Problem with message, information groups, and tension leads, Environment Profile, audience encounter, Visual source inventory, differentiation strategy, tagged design implications).

## Phase sheet

| Item | Content |
|---|---|
| Goal | As in the opening paragraph: one unified, defensible, original direction, synthesizing all findings into a single concept |
| Receives | As under Inputs needed above |
| Decisions | Plan criteria (space budget, tension leads, carry targets); territory survey; brand design and theme; core idea; style (seven dimensions); hero or its deliberate absence; governing principles (`04_principles_and_plan_evaluation.md` F); the quality carrier map; how each Phase 2 tension is carried; stress-test results |
| Exploration | Full protocol (`exploration_protocol.md` section 2) for core idea, style, and hero, in that order: the winning idea is a criterion for style, and the winning style a criterion for the hero. Write no style card before the core idea is chosen. Each decision has at least one card from the survey, inventory, or departure dimensions. Check renderability and fit throughout |
| Output | The Design Plan (Forward) and the record of rejected directions (Record) |
| Entry fields | (the source for the user's table; `ux_wait_notes_entries_and_final_reply.md` section 5 decides what is shown): for core idea, style, hero, and the principles that had real alternatives (space intent, mark role, and imagery and decoration stance always): the choice, a one-sentence reason in the subject's terms (the decisive criterion in plain words), and at most two alternatives with their weakness, the apparent option included when weighed. Add one line on how each stated quality is carried. Mark decisions fixed by the user or evidence as such. |
| Forward | Brand design and theme; core idea; style (seven dimensions, balance type included); hero with hosting capacity and footprint (share of the format, edge behavior); principles (space intent, imagery and decoration stance, supporter budget and treatment vocabulary, integration, mark role, layering, tone and positioning, density, character carriers and links, boundaries, point of tension, figure stance); how each tension is carried; the **seed bank** (each surveyed territory as name, defining traits, one-line lineage; not the survey tables); carry-forward obligations; open flags. The quality carrier map is entered in S |

## 1. Process

1. Set the plan criteria, decide brand design and theme (A), and survey territories (B).
2. Decide the core idea (C), then style (D), then hero (E), each by the full protocol.
3. Decide the governing principles and confirm how each Phase 2 tension is carried (`04_principles_and_plan_evaluation.md` F).
4. Evaluate the assembled plan as one system and run the direction check (`04_principles_and_plan_evaluation.md` G); gate.

## 2. Guidance

### Plan criteria (set before any card)

Fix what every card is judged against, so no choice is made blind to a constraint it must meet.
1. **Space budget** (provisional space intent): one table of single numbers that sums to 100, an envelope the plan stays inside and Phase 5 re-derives from the real composition. Rows: each information group (its Phase 2 load-table row, wraps and gaps included); structure and decoration; the **quiet share** (floor about 8%, with its jobs and where it tends to live; `terms_design_system.md`, Space intent); outer margin and separations (about 6% to 10%); headroom (at least 3%); and the hero group. Fill it in that order: the hero row is the **residual**, what its message needs (read from the glance parts) and never more than what is left. Any **atmosphere** the style's world calls for (decorated fields, never counted as quiet) is paid for from the structure-and-decoration row and the hero's surround. When the residual is below the hero's minimum share (Phase 2), the brief is dense: pre-apply the fit-ladder rungs now (a compact arrangement, reference content to a nearer stage, a simpler hero lockup), keep core content at its floors, and record the volume risk. Derive the rows from the format's proportion and orientation, the role floors in the Environment Profile, and the positioning the brief implies, for every deliverable at its own ratio. Do not size strings, arrange rows, or draw a layout here; Phase 5 does that once, on the chosen composition. A hero card whose footprint exceeds its row is dropped at the screen (E). The budget narrows only through the fit ladder (`terms_design_system.md`, Fit ladder (full)), never because an attractive card needs room.
2. **Tension leads:** for each Phase 2 tension still open, the side that leads (by `global_standards.md` section 7, the user's priority, and the Communication Problem) and the minimum the other side keeps.
3. **Carry targets:** the Phase 2 message and the quality requirements the core idea must be able to carry.

Criteria are constraints on candidates, not decisions with cards. Revise one only when a card shows it was infeasible, and record the change.

### A. Brand design and theme

Compare two ways to express the brand's impression in this environment. Then state **brand design** and **theme** separately, so the theme can vary without damaging the brand:
- **brand design:** the enduring identity. Fixed assets bind it; for a new brand, propose it with restraint proportional to evidence.
- **theme:** the idea for this piece, built on the brand design.

Check that the theme does not contradict the brand design (otherwise the theme is wrong, or the brand needs a deliberate, approved evolution) and that it leaves room for a specific core idea.

### B. Territory survey

Shallow options come from the model's category associations; widen the field before writing any card. Survey territories across source families (counts by openness: `scope_roles_and_depth.md` section 6):
- historical and movement lineages in design, illustration, lettering, and print;
- regional and vernacular traditions of the subject's place or community;
- craft, material, and production traditions;
- contemporary practice in other categories and regions;
- the subject's own world (inventory and profile).

Record each territory in one table row:
- defining traits (depiction mode, technique, line and form behavior, material and surface, ornament, pattern, and framing vocabulary, light, chromatic logic, typographic stance, compositional behavior);
- the lineage and conditions it arose from, so it is used with understanding, not as surface;
- where it is true to this subject and where it would be imported whole;
- behavior at glance and approach in the real setting;
- reproduction and renderability demands.

Work from knowledge first and record each territory's traits, not its label. Run a targeted query only for a territory whose traits are uncertain (one query, at most one page read; trend and listicle pages are not evidence of traits) and mark what stays unverified provisional. Study precedents for principles, never copy a competitor or an existing design. Verify any culturally loaded territory or omit it.

### C. Core idea

A core idea relates something true about the subject to something the audience recognizes, in a way that suggests a visual structure. A mood word or product category is not one. Cards differ on a structural axis (what carries the identity, what the viewer does first, how information is structured, register, image-making method).

**Card fields:**
1. the idea in one sentence;
2. source (territory, inventory item, departure dimension, weakest link, differentiator, name or origin);
3. the true thing and the audience recognition it relates;
4. the visual structure it suggests;
5. behavior in the setting at each encounter stage;
6. risks (renderability, capacity);
7. compatibility with each quality requirement.

**Five properties** every leader must show:
- **specific:** this subject's;
- **visual;**
- **generative:** theme, hero, style, and layout can follow;
- **truthful;**
- **functional:** helps the piece work in its setting and reads at the glance stage without being decoded.

Also check its interaction with brand design and theme.

### D. Style

One synthesis resolved across seven dimensions, each in specialist terms:
1. **Visual language:** form and line behavior, corner and edge geometry (the root of the shape language), abstraction, geometric or organic.
2. **Influences,** named by lineage and the traits borrowed (traditions, movements, eras, techniques, materials, and regional print cultures; never an individual living artist, studio, or protected character or brand).
3. **Compositional behavior:** axis, alignment, grid logic, figure-ground, plane behavior and layer cues, balance type (symmetric, asymmetric equilibrium, radial, deliberate tension), tension, rhythm.
4. **Material character and visual world:** surface, texture, the physical process evoked, and the decorative vocabulary the territories and inventory offer (pattern and motif families, ornament, border and framing character, how the ground is layered), stated as what this piece's world contains and where it would live in the composition, or as a decision that it holds none.
5. **Image-making technique and rendering logic,** stated as a specific language for each image type the piece uses, derived from this brand and its territories and never a medium or category name (a medium plus "flat" or "sticker" states no style), each property stated so a prompt can carry it:
   - illustration: lineage, proportions, linework, rendering, texture, detail level, color treatment, degree of stylization;
   - photography: framing, light, grade, finish, retouch level;
   - mixed media: how the media combine.
6. **Typographic expression:** the lettering's voice and lineage (what it says about this subject), classification, stroke contrast, proportion, spacing and density character, how the display and informational voices contrast, and alignment and orientation tendencies.
7. **Light, atmosphere, chromatic stance:** light direction and quality, tonal key, value structure, temperature and harmony logic (Phase 4's palette must realize it).

**Card:** one entry per dimension, plus territories drawn on, the core idea realized, and quality compatibility. Mood adjectives are not a card. For each open dimension of the leading cards (a dimension the brief fixes is recorded as fixed), compare at least two options and repair any conflicting dimension before choosing. Style comes from synthesis of this brief's conditions, not arbitrary additions; a familiar combination needs an evaluated justification. Options differ in lineage, surface, light, and finish, not in medium names alone. Renderability is judged on what must be exact (text, counted forms, mark geometry), never as a reason to take the plainest illustration language: a concretely described rich style is usually rendered well.

**Per-zone application.** A style is one visual language applied differently by zone: fully drawn in the illustration and its ground, calm where information is read. Texture, grain, or detail that would harm text stays out of the text zones; it does not disqualify a lineage.

**Specificity test (the card is not accepted until it passes).** Strike the medium and category words (flat, vector, sticker, kawaii, cartoon, pop) and bare mood adjectives (cute, playful, friendly, modern, minimal, clean) from dimensions 1, 4, and 5. What remains must still describe a distinct, drawable look: the lineage, how shapes are built and proportioned, line behavior, how form is rendered, surface, and detail steps by rank. If it does not, rewrite the dimension; relabeling the option does not pass.

### E. Hero

- **Options:** symbolic marks, objects, products, in-use scenes, places, figures (supplied or wanted), illustrations, photography, abstract forms, typography-led concepts, an equal set of images, or no hero.
- **When to choose a hero:** only when one subject deserves primary attention and a renderable depiction exists. When several messages weigh equally or no suitable depiction exists, choose no hero or a small equal set, never a forced focal image.
- **Figures:** a figure leads only when supplied or wanted, as a designed character (Phase 4), never a stock figure or a real person's likeness. This card fixes the figure's role, depiction mode, and pose family; its identity is developed in Phase 4 (`07_visual_supporters_and_figures.md`).
- **Depiction mode** follows what must be true: where the viewer must see exactly what is sold, a mode that stylizes it away is ineligible.
- **Standalone logo request:** the mark is the hero by definition (the protocol still runs for idea and style).

**Card:**
1. What it is, down to the true specifics (form, material, construction, arrangement), with depiction mode and technique.
2. What it truthfully represents.
3. The stage at which it registers.
4. Which mark roles it permits (leads, anchors, signs off) and which would crowd it.
5. renderability (`terms_brief_and_context.md`), avoiding real identifiable people and dependence on complex hands, crowds, or fine faces.
6. Footprint against the budget: its share of the format and its edge behavior (cropped by the trim, inside the margin), including any text it hosts at that text's floors; the smallest share that carries the message at its stage. A card whose footprint exceeds the budget's hero row is dropped after one line.
7. Quality compatibility.
8. Purpose line (`terms_design_system.md`): the function it serves toward the message, what is lost without it, and the effect it must have at its stage.
9. Hosting capacity:
   - what its form and visible parts can carry (text along or over its contour, callouts to its named parts, an overlapping tag, supporting elements that surround or overlap its edge, groups that interlock with its silhouette);
   - which related information groups or supporters, from S, Phase 2, and the inventory, would reinforce its message, clarify its value, or give context, at what scale and edge behavior (isolated, or running to the trim);
   - which parts may sit in front of or behind text;
   - for a circular, arched, or otherwise non-rectangular host, the text capacity by geometry, solved once: a block centered in a circle needs a diameter of at least √(w² + h²) + 2 × clearance (w the widest line, h the block's height); a stack whose lines narrow toward its top and bottom is tested line by line, each width against the chord 2√(r² − y²) at the line's farther edge (y from the center). The host is sized from its text at the floors, never the text from the host, and a host that cannot hold its text inside the footprint is dropped with the card.

The hero's scale, crop, and edge behavior must express the message, not merely fit: a hero too small or contained for its message fails even if attractive. It is equally bounded by the budget: a hero is never enlarged to fill room the plan holds as quiet or assigns to other roles.

## Quality checks

**Gate checks for this step (fails if any is false):**
- The survey meets the openness minimum; no direction derives from a competitor or existing design; no territory is used as surface without its lineage understood.
- Every card field the phase sets is filled in the protocol's specialist terms (`exploration_protocol.md` section 4); no apparent option won without a decisive criterion; the leaders passed the protocol's three tests; every material weakness has a move or an accepted cost.
- The core idea fits one sentence and shows the five properties. Style is one synthesis across all seven dimensions, its image-making language passes the specificity test (section D) and the swap test against a peer brand, and no style option was dropped on renderability or load alone without naming what would fail and whether per-zone application removes it. The hero has a stated stage and reach, depicts only what is sold, was chosen under the hero rule (one subject deserves primary attention and a renderable depiction exists; otherwise no hero or an equal set), and has its reinforcing content and supporters decided or a recorded reason to stand alone. A figure exists only if supplied or wanted, and has a role.
- Plan criteria were set before the first card, and any change to them is recorded.

