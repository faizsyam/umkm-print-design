# Phase 2: Analysis

Establish the piece's real problem and setting well enough that every later decision rests on a finding; findings are reduced to design implications plus the Environment Profile and the Visual source inventory.

**Inputs needed:** S and the Phase 1 Forward block (research questions, tensions, open flags). Outside: research, only where it can change a decision.

## Phase sheet

| Item | Content |
|---|---|
| Goal | Establish the piece's real problem and setting so that every later decision rests on a finding. Findings are reduced to design implications plus two creative inputs: the Environment Profile and the Visual source inventory |
| Receives | S and the Phase 1 Forward block (research questions, tensions, open flags). Outside: research, only where it can change a decision |
| Decisions | Which research questions to pursue; differentiation strategy (or execution-led); weakest link; the message; information groups; medium reading and encounter stages; departure and fit dimensions; Visual source inventory; design implications |
| Exploration | Compact comparison (`exploration_protocol.md` section 3), genuine option sets only |
| Output | Communication Problem (with the message, information groups, and load table); Environment Profile (encounter, medium reading, encounter stages with their role floors); audience encounter; differentiation strategy; Visual source inventory; tagged design implications; tensions |
| Entry fields | Guided mode: no separate stop. Findings lead the Phase 3 entry in two lines, from these fields: weakest link; the context and where the piece departs from it; how it stands out (or "fixed by evidence") |
| Forward | Communication Problem (primary objective, weakest link, message, information groups, load table, tensions with the lead side where `global_standards.md` section 7 decides it); Environment Profile with encounter, medium reading, encounter stages, departure and fit; audience encounter; differentiation strategy; Visual source inventory; tagged design implications; open flags (provisional setting, unverified specifics). S is not restated |

## 1. Process

1. Triage research questions: keep only those that name a decision they inform.
2. Read the brand (A) and run the research (F), early enough that the profile, differentiation, and inventory rest on it.
3. Build the Environment Profile (C) and the audience encounter (D).
4. Find differentiation (B) against the peers the profile identifies, and ground culturally to build the Visual source inventory (G).
5. Build the Communication Problem and group the necessary information (E), which reads the profile, the encounter, and the differentiation.
6. Convert findings into design implications (form: `terms_brief_and_context.md`, Design implication; tagged); discard any finding that yields none. Carry the Phase 1 quality translations forward as given implications.
7. Gate.

## 2. Guidance

### A. The subject as it is

Record the values, personality, and positioning shown by what the subject does and says; the credibility it actually holds (origin, skill, history, proof supplied); the commissioner's aspirations; and the relationship with the audience.
- Separate established fact from plausible interpretation, and aspiration from reality.
- Downgrade any reading richer than its evidence.
- Record the traits to express and the claims not to make.

### B. Differentiation

List candidate differentiators from the subject's specifics, process, materials, origin, scale and intimacy, behavior, offer logic, location, people, name, signature item, ritual, and what each peer already claims. Test each:
- **true:** the subject can honestly claim it (failure discards it);
- **relevant:** the audience cares at the moment of encounter;
- **distinctive:** not shared by dozens of peers;
- **visualizable:** can become something seen (a failure may still shape tone or hierarchy).

Choose a strategy. If none is strong, choose execution-led differentiation (the piece differs through how it is composed and made) and say so. Record the options with their test results.

### C. Environment Profile (governing parameter)

One profile per distinct context; deliverables that share a context share its profile. Start from the Phase 1 inference and test it against the user's account and research. Derive each part by reasoning from how the deliverable is made, shown, and reached, never from its medium's name.

- **Encounter:** where and how the deliverable reaches its audience.
  - What surrounds it: neighbors' dominant colors, density, scale, order or clutter, finish; competing stimuli; the physical or on-screen setting.
  - The audience's state there: goal, passive or active, moving or still, attention and time, distance or display scale, light or display conditions, cultural context.
  - The reading path: the audience's script direction and habits.
- **Encounter stages** (`terms_brief_and_context.md`): the ordered moments of engagement that follow from the encounter. For each, record what the audience can perceive, the attention and time it has, what it is trying to decide or do, and whether it can reach the stage (a stage the audience cannot reach cannot carry content). Derive their number and nature; do not assume the usual three. Record each stage's reading distance or display scale as a figure or range (where the audience reads that stage's content, not the extreme of the range), its engagement (passing, approaching, or deliberate) and, once, the floors it implies for its role classes (comfortable readability and deliberate reading): each the larger of the role floor and the raster floor (`terms_brief_and_context.md`, Legibility minimum and Render scale), in mm and as a fraction of the format's height, with the render scale assumed. A stated viewing range gives its far end to glance content alone, and the glance stage holds only what a passing viewer needs. Phases 3 to 5 read these floors and never recompute them.
- **Medium reading:**
  - what the medium **imposes**: what making, reproducing, or displaying does to an image between the generated file and the audience, and the limits it sets;
  - what the audience **relies on**: conventions learned for this kind of piece (structure, reading path, where information is expected);
  - what the medium **affords**: what it can do that others cannot.

  Record only what changes a decision. No medium convention is applied by default (`global_standards.md` principle 10): keep a convention where departing costs the audience effort or credibility; depart where it is the apparent option and the purpose gains.
- **Impression versus expression.** Hold the **impression** constant and let the setting decide the **expression**. The impression is what the viewer should feel and conclude about the subject (from the desired perception and the quality requirements). The expression is the visual means that deliver it (palette, density, scale, form), chosen to suit this context.
- **Departure and fit.**
  - Find where neighbors are uniform on a dimension (color, density, scale, order, finish, form). Distinctness is relative to neighbors on a dimension and can lie in either direction; more intensity is not by itself departure.
  - Choose the **departure** dimensions where the piece differs, and record the **fit** dimensions where it must still conform (conventions the audience relies on, credibility cues) so it is not rejected or misread. The occasion, culture, and atmosphere the brief names are fit dimensions: departure beats their apparent signifiers by specificity and craft (a particular pattern, material, or custom drawn from the inventory), never by omitting them. The departure is a decision with a reason, never a default.
- If the context cannot be established, state the most probable one and mark it provisional.

### D. Audience encounter

Record cultural references, behavior, motivations, decision considerations, the language register the audience trusts, and the trust cues the context provides or lacks. Record what the audience does and must conclude at each encounter stage. Drop demographic stereotypes and unsupported psychology.

### E. Communication Problem

**Objectives and response.** A user-stated priority fixes the primary objective; the weakest link is chosen within it and never replaces it. Record the desired response, the necessary information, and the desired perception of the subject (quality requirements included).

**Information groups.** Gather the necessary information into groups by the job each group does toward the objective and the weakest link. Jobs worth reading the brief for: carrying the primary proposition, supporting or explaining what the viewer sees first, enabling the offer and the action, substantiating trust, helping the viewer evaluate, giving practical and contact information, relating further offerings. These are lenses, never a fixed list; derive the groups this brief's content and objective actually form. For each group record its items, its stage, what it refers to, its internal hierarchy (a lead item and supporting items need not share prominence), and its volume. A group is formed by shared job, not by similar appearance or by the order the user listed the content. Later phases read the groups; Phase 5 refines them per deliverable. Then, once, record the **load table**: one row per group, and a name or phrase whose parts do different jobs gets one row per part (the **glance part** at the glance floor, the remainder at its own stage's floor; `terms_brief_and_context.md`, Encounter stage). Each row gives its characters, the floor of its text (Environment Profile), and its area share of the format: characters × floor cap height × a width factor of about 0.8 × a line pitch of about twice the cap height × 1.3 for wraps and item gaps. Add the total, and the hero's **minimum share** (the smallest hero that carries the message at the glance floor, read from the glance parts only). This is the only text-area estimate in the workflow: Phase 3 builds the budget from it and Phase 5 reads each group's space need from it, never re-estimating. A group sits at the glance stage only if its text at the glance floor fits beside the hero's minimum share; otherwise it is assigned to the approach stage here, and its row uses that stage's floor. The brief is **dense** when the rows, the hero minimum, the structure-and-decoration line (about 5%), the quiet floor (about 8%), and 3% headroom exceed 100%; this is stated once with the way out, and Phase 3 pre-applies the fit-ladder rungs.

**Tensions.** List pairs of needs that compete for the same limited resource (attention at the glance stage, space, legibility distance, budget, register). State each as the two needs and the resource they share.

**Weakest link.** Choose the link in the chain from encounter to the intended outcome (attention → comprehension → credibility → action, keeping the links the purpose needs) that is most likely to fail in this context, weighing the cost of each failure. Test the brief's own assumptions (the deliverables asked for, the audience assumed, the success measure): where one would undermine the objective, record it as a tension and handle it per `global_standards.md` section 7. Where `global_standards.md` section 7 or the user's stated priority decides a tension, record its lead side; Phase 3 decides the rest.

**Message.** One sentence naming what the glance-stage viewer takes away and does next, compressed from the desired response and the necessary information. It serves the primary objective and never contradicts a quality requirement. Phase 3 builds the core idea to carry it; Phase 5 confirms it after triage.

### F. Research

Research is a question, not a phase. Run it only for a question that names a Direction decision it could change and that the brief and knowledge cannot answer: at most three targeted queries and one page read per question, stopping at the first sufficient answer; independent questions run together. If Phase 1 passed no such question, record "no research needed" and proceed. Trend articles and listicles are not evidence of visual traits, and no search is run to survey a category.

- **Priority:** the subject and its public materials; visual conventions of the category and medium to differ from or conform to; peers and alternatives; the environment; cultural references; the offering's reality.
- **Sources:** prefer authoritative and first-hand ones. Reviews show perception, not fact. Confirm that a found subject is the right one (same name is not same subject). Competitor visuals are a baseline to differ from, never a model.
- **Without research tools:** reason from the brief, mark conclusions provisional, and avoid choices that depend on unverified specifics.
- Record findings with provenance and the decision each informs.

### G. Cultural grounding and the Visual source inventory

- Identify the cultures, languages, religions, and commercial conventions actually relevant (a national or ethnic label names many aesthetics and audiences). Preserve the user's register. Use regional or traditional references only where the subject genuinely connects to them.
- Mine deeper specifics across seven dimensions: practices and rituals; materials and tools, with their surface, pattern, and ornament traditions; how things are made, handled, and shared; spatial and sensory details of daily life; language, its play, and its lettering traditions; geography and seasons; the history of this subject.
- Screen each specific:
  - **true:** the subject can claim it;
  - **respectful:** no tokenism;
  - **meaning verified:** omit a culturally loaded symbol if uncertain;
  - **workable:** can be seen, drawn, and rendered at distance, and can be depicted truthfully (the offer, in use, a place, or from supplied imagery); a depiction the generator cannot render accurately is not workable.
- A figure the user wants is sourced from the same true specifics, never the category's stock mascot.

Record the inventory in three parts: (1) apparent associations as baseline; (2) deeper true specifics that could become visual ideas (at least one beyond the baseline); (3) which of them are visually workable.

## Quality checks

**Gate checks for this step (fails if any is false):**
- Every finding changes or confirms a named decision; every implication cites a tagged finding; a claim with no finding is removed.
- Differentiation fails the swap test (substituting a named peer for the subject makes it false) and shows its option set (or "fixed by evidence"), each option differing from the others on a named criterion.
- The profile fills every part of the Environment Profile definition (`terms_brief_and_context.md`) for each deliverable and fails the context-swap test (substituting another setting of the same category invalidates at least one part). Departure names its dimension and the visible difference, differs in more than size or brightness, and contradicts no quality requirement.
- Primary objective follows the user's stated priority; the weakest link is a secondary lens, not a replacement.
- The inventory holds at least one source that is not an emblem (object, material, craft, place, or visual practice); every symbol is verified for the meaning it holds for this audience; no competitor is a source; every audience claim cites evidence.
- The message is one takeaway, serves the primary objective, and contradicts no quality requirement. The information groups follow from the objective and the content, each with its job, stage, referents, and internal hierarchy; none comes from a template or from the order of the user's list.

**Entry fields:** in the phase sheet; mark decisions fixed by evidence as such.

## Next

Run the gate (the checks above, then the hand-off check in `SKILL.md`, Checks) and append the Phase 2 decisions (D) to the Design Log. Guided mode: no separate stop; Phase 2's findings lead the Phase 3 entry. Load batch 3 (`SKILL.md`, Loading).
